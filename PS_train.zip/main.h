#define Precision double
