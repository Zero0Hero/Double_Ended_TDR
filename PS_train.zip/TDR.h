#include <iostream>
#include "main.h"
#define N_Node 12

Precision TDR(Precision U_x, Precision x_lt[N_Node], Precision x_t[N_Node], Precision Mask[N_Node], Precision W[N_Node], char mode);


