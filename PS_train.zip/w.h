#include <iostream>
#include "stdio.h"
#include <string.h>
#include "main.h"
#define M 6000

void W_N_48(Precision X[48][M], Precision W[48], Precision Y[M]);
void W_N_12(Precision X[12][M], Precision W[12], Precision Y[M]);


#pragma once
